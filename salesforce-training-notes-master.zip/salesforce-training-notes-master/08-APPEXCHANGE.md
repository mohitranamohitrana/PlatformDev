# AppExchange
- Salesforce has a community of partners that use the flexibility of the Salesforce platform to build amazing apps and other solutions that anyone can use. These offerings are available (some for free, some at a cost) for installation on AppExchange.

## Link to AppExchange
- [AppExchange](https://appexchange.salesforce.com)